import React from 'react';
import { createRoot } from 'react-dom/client';
import { Building2, Home, Users, Wrench, CreditCard, Phone, Mail, MapPin, ShieldCheck, FileText, ArrowRight } from 'lucide-react';
import './styles.css';

function App() {
  const services = [
    { icon: <Home />, title: 'Residential Property Management', text: 'Full-service management for single-family homes, multifamily units, and residential rental portfolios.' },
    { icon: <Users />, title: 'Tenant Placement & Screening', text: 'Professional leasing support, application review, background checks, rental history, and income verification.' },
    { icon: <CreditCard />, title: 'Rent Collection', text: 'Online rent collection, automated receipts, owner reporting, and payment tracking.' },
    { icon: <Wrench />, title: 'Maintenance Coordination', text: 'Maintenance request intake, vendor coordination, repair tracking, and tenant communication.' },
    { icon: <FileText />, title: 'Owner Reporting', text: 'Monthly statements, expense tracking, income reports, and property performance updates.' },
    { icon: <ShieldCheck />, title: 'HOA & Compliance Support', text: 'Community oversight, violation tracking, resident communication, and administrative support.' },
  ];

  return (
    <main>
      <header className="nav">
        <div className="brand">
          <div className="logo"><Building2 size={26}/></div>
          <div>
            <strong>GCS CAPITAL LLC</strong>
            <span>Georgia Residential Property Management</span>
          </div>
        </div>
        <nav>
          <a href="#services">Services</a>
          <a href="#portals">Portals</a>
          <a href="#payments">Payments</a>
          <a href="#contact" className="navBtn">Contact</a>
        </nav>
      </header>

      <section className="hero">
        <div className="overlay"></div>
        <div className="heroContent">
          <p className="eyebrow">Established 2026 • Georgia LLC • Control No. 26060415</p>
          <h1>Advanced Residential Property Management for Owners, Investors & Tenants.</h1>
          <p className="sub">
            GCS Capital LLC provides professional residential property management, tenant support, rent collection, maintenance coordination, and owner reporting throughout Georgia.
          </p>
          <div className="heroActions">
            <a href="#contact" className="primary">Request Management Quote <ArrowRight size={18}/></a>
            <a href="#payments" className="secondary">Make a Payment</a>
          </div>
        </div>
      </section>

      <section className="stats">
        <div><strong>2026</strong><span>Established</span></div>
        <div><strong>Georgia</strong><span>Domestic LLC</span></div>
        <div><strong>24/7</strong><span>Online Requests</span></div>
        <div><strong>Secure</strong><span>Payment Ready</span></div>
      </section>

      <section className="section about">
        <div>
          <p className="eyebrow dark">About GCS Capital LLC</p>
          <h2>Built for modern real estate ownership.</h2>
          <p>
            GCS Capital LLC is a Georgia-based real estate company focused on residential property management. We help property owners protect their assets, improve tenant communication, streamline rent collection, and keep maintenance organized.
          </p>
          <p>
            Our principal office is located at 600 W Peachtree St NW Ste 1700 PMB 454, Atlanta, GA 30308.
          </p>
        </div>
        <div className="aboutCard">
          <h3>What We Manage</h3>
          <ul>
            <li>Single-family rental homes</li>
            <li>Residential investment properties</li>
            <li>Small multifamily properties</li>
            <li>HOA and residential community support</li>
            <li>Owner/investor portfolios</li>
          </ul>
        </div>
      </section>

      <section className="section black" id="services">
        <p className="eyebrow">Services</p>
        <h2>Complete property management solutions.</h2>
        <div className="grid">
          {services.map((s) => (
            <div className="service" key={s.title}>
              <div className="icon">{s.icon}</div>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section" id="portals">
        <p className="eyebrow dark">Online Portals</p>
        <h2>Simple access for tenants and owners.</h2>
        <div className="portalGrid">
          <div className="portal">
            <h3>Tenant Portal</h3>
            <p>Submit maintenance requests, make payments, send documents, and contact management.</p>
            <a href="#contact">Request Tenant Access</a>
          </div>
          <div className="portal darkPortal">
            <h3>Owner Portal</h3>
            <p>Access owner statements, property updates, financial reports, lease tracking, and maintenance status.</p>
            <a href="#contact">Request Owner Access</a>
          </div>
        </div>
      </section>

      <section className="section payments" id="payments">
        <p className="eyebrow dark">Merchant Services Ready</p>
        <h2>Secure credit & debit card payment setup.</h2>
        <p>
          This website is designed to connect with Stripe, Square, Authorize.net, or another merchant services provider for online rent, invoices, and property management payments.
        </p>
        <a className="primary center" href="#contact">Request Payment Link</a>
      </section>

      <section className="section contact" id="contact">
        <div>
          <p className="eyebrow dark">Contact GCS Capital LLC</p>
          <h2>Let’s discuss your property management needs.</h2>
          <div className="contactInfo">
            <a href="tel:7703761619"><Phone/> 770-376-1619</a>
            <a href="mailto:George.scott@gcscapital.co.site"><Mail/> George.scott@gcscapital.co.site</a>
            <p><MapPin/> 600 W Peachtree St NW Ste 1700 PMB 454, Atlanta, GA 30308</p>
          </div>
        </div>

        <form action="mailto:George.scott@gcscapital.co.site" method="post" encType="text/plain" className="form">
          <input name="name" placeholder="Full Name" required />
          <input name="email" type="email" placeholder="Email Address" required />
          <input name="phone" placeholder="Phone Number" />
          <select name="service">
            <option>Property Management Inquiry</option>
            <option>Tenant Support</option>
            <option>Owner Portal Request</option>
            <option>Payment Question</option>
            <option>Maintenance Request</option>
          </select>
          <textarea name="message" placeholder="How can GCS Capital LLC help you?" rows="5" required></textarea>
          <button type="submit">Send Message</button>
        </form>
      </section>

      <iframe
        title="GCS Capital LLC service area map"
        className="map"
        src="https://www.google.com/maps?q=600+W+Peachtree+St+NW+Atlanta+GA+30308&output=embed">
      </iframe>

      <footer>
        <strong>GCS CAPITAL LLC</strong>
        <span>© 2026 GCS Capital LLC. Georgia Residential Property Management.</span>
        <span>Control Number: 26060415</span>
      </footer>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
